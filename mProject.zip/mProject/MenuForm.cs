﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mProject
{
    enum RowState
    {
        Existed,
        New,
        Modified,
        ModifiedNew,
        Deleted
    }
    public partial class MenuForm : Form
    {
        DB db = new DB();
        int SelectedRow;
        public MenuForm()
        {
            InitializeComponent();
            
        }

        private void CreateColums()
        {
            dataGridView1.Columns.Add("id", "id");
            dataGridView1.Columns.Add("client_id", "Client_ID");
            dataGridView1.Columns.Add("book", "Book");
            dataGridView1.Columns.Add("IsNew", String.Empty);

        }

        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetInt32(0), record.GetInt32(1), record.GetString(2), RowState.ModifiedNew);
        }

        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string queryString = $"select * from users";

            SqlCommand command = new SqlCommand(queryString, db.GetConnection());
            db.OpenBd();
            SqlDataReader dr = command.ExecuteReader();

            while(dr.Read())
            {
                ReadSingleRow(dgw, dr);
            }
            dr.Close();
        }

        private void MenuForm_Load(object sender, EventArgs e)
        {
            CreateColums();
            RefreshDataGrid(dataGridView1);
        }

        private void Del_Btn_Click(object sender, EventArgs e)
        {
            DelRow();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
           
        }

        private void DelRow()
        {
            int index = dataGridView1.CurrentCell.RowIndex;
            if (dataGridView1.Rows[index].Cells[0].Value.ToString() == string.Empty)
            {
                dataGridView1.Rows[index].Cells[4].Value = string.Empty;
                return;
            }
        }

        private void Update()
        {
            for(int index = 0; index < dataGridView1.Rows.Count; index++)
            {
                var rowState = (RowState)dataGridView1.Rows[index].Cells[5].Value;

                if (rowState == RowState.Existed)
                    continue;

                if(rowState == RowState.Deleted)
                {
                    var id = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
                    var deleteQ = $" delete from books where id = {id}";

                    var command = new SqlCommand(deleteQ, db.GetConnection());
                    command.ExecuteNonQuery();
                }

                if(rowState == RowState.Modified)
                {
                    var id = dataGridView1.Rows[index].Cells[0].Value.ToString();
                    var log = dataGridView1.Rows[index].Cells[0].Value.ToString();
                    var pas = dataGridView1.Rows[index].Cells[0].Value.ToString();

                    var ChangeQ = $" update books set UserLoginId = '{log}' and UserPassword = '{pas}'";

                    var command = new SqlCommand(ChangeQ, db.GetConnection());
                    command.ExecuteNonQuery();
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Update();
        }

        private void Ed_Btn_Click(object sender, EventArgs e)
        {
            change();
        }
        private void change()
        {
            var SelectedRowIndex = dataGridView1.CurrentCell.RowIndex;
            var id = tbUser.Text;
            var log = tbLogin.Text;
            var pas = tbPassword.Text;
            

            
        }
    }
}
