﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace mProject
{
    internal class DB
    {
        SqlConnection sqlconnection = new SqlConnection(@"Data Source = LAPTOP\SQLEXPRESS02; Initial Catalog = books; Integrated Security = True");
        public void OpenBd()
        {
            if(sqlconnection.State == System.Data.ConnectionState.Closed)
            {
                sqlconnection.Open();
            }
        }
        public void CloseBd()
            
            {
            if (sqlconnection.State == System.Data.ConnectionState.Open)
            {
                sqlconnection.Close();
            }
        }
        public SqlConnection GetConnection() 
        { 
            return  sqlconnection;
        }
    }
}
