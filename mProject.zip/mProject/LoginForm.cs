﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace mProject
{
    public partial class LoginForm : Form
    {
        DB db = new DB();

        public LoginForm()
        {
            InitializeComponent();

        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CloseBtn_MouseEnter(object sender, EventArgs e)
        {
            CloseBtn.BackColor = Color.Red;
        }

        private void CloseBtn_MouseLeave(object sender, EventArgs e)
        {
            CloseBtn.BackColor = Color.White;
        }
        Point lastPoint;
        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);

        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            var LoginUser = IDTextBox.Text;
            var PasswordUser = PasswordTextBox.Text;

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();

            string querystring = $"select id, UserLoginId, UserPassword from users where UserLoginId = '{LoginUser}' and UserPassword = '{PasswordUser}' ";

            SqlCommand command = new SqlCommand(querystring, db.GetConnection());
            adapter.SelectCommand = command;
            adapter.Fill(table);
            //-
            db.OpenBd();
            if (table.Rows.Count == 1)
            {
                MessageBox.Show("Ok");
                MenuForm logForm = new MenuForm();
                this.Hide();
                logForm.ShowDialog();
                this.Show();
            }
            else
            {
                MessageBox.Show("No");
            }
            db.CloseBd();
        }
       
    }
}
